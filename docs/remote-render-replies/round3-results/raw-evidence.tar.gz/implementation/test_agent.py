from __future__ import annotations

import json
import hashlib
import os
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

from agent import Agent, RenderError


class AgentValidationTests(unittest.TestCase):
    def test_worker_failure_ends_parent_and_reports_failed(self) -> None:
        import agent
        with tempfile.TemporaryDirectory() as temp:
            old = agent.ROOT
            agent.ROOT = Path(temp)
            process = None
            try:
                a = Agent()
                job = a.job_root('worker-fault')
                a.write_status('worker-fault', {'state': 'running', 'progress': 0.0})
                process = subprocess.Popen(
                    [sys.executable, '-u', '-c',
                     "import time; print('worker 2 failed (exit 1)'); time.sleep(60)"],
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    text=True, start_new_session=True,
                )
                a.processes['worker-fault'] = process
                a.process_workers['worker-fault'] = 16
                started = time.monotonic()
                a._watch('worker-fault', process, (job/'logs/render.log').open('w'))
                self.assertLess(time.monotonic()-started, 15)
                state = a.read_status('worker-fault')
                self.assertEqual(state['state'], 'failed')
                self.assertEqual(state['error'], 'worker 2 failed (exit 1)')
                self.assertFalse(a.processes)
                self.assertFalse(a.process_workers)
            finally:
                if process is not None:
                    if process.poll() is None:
                        process.kill()
                    process.wait()
                    process.stdout.close()
                agent.ROOT = old

    def test_relative_paths_and_output_rewrite(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            import agent
            old = (agent.ROOT, agent.SOCKET)
            agent.ROOT = root
            try:
                a = Agent()
                (root / "runtime" / "rt" / "remotion-composer" / "render-tools").mkdir(parents=True)
                (root / "runtime" / "rt" / "remotion-composer" / "package.json").write_text("{}")
                (root / "runtime" / "rt" / "remotion-composer" / "render-tools" / "render_chunks.mjs").write_text("")
                job = a.job_root("smoke")
                (job / "input" / "props.json").write_text("{}")
                (job / "input" / "public").mkdir()
                spec = {"propsPath": "props.json", "publicDir": "public", "chunks": [{"out": "chunk.mp4", "from": 0, "to": 2}]}
                (job / "input" / "jobs.json").write_text(json.dumps(spec))
                resolved, _ = a._validate_jobs("smoke", "rt", "jobs.json")
                self.assertTrue(str(job / "output" / "chunk.mp4") == resolved["chunks"][0]["out"])
                still_spec = {
                    "propsPath": "props.json",
                    "publicDir": "public",
                    "stills": [{"out": "t00025.png", "frame": 25}],
                }
                (job / "input" / "still.json").write_text(json.dumps(still_spec))
                still_resolved, _ = a._validate_jobs("smoke", "rt", "still.json")
                self.assertTrue(str(job / "output" / "t00025.png") == still_resolved["stills"][0]["out"])
                with self.assertRaises(RenderError):
                    bad = dict(spec, propsPath="../outside.json")
                    (job / "input" / "bad.json").write_text(json.dumps(bad))
                    a._validate_jobs("smoke", "rt", "bad.json")
            finally:
                agent.ROOT, agent.SOCKET = old

    def test_source_overlay_lock_and_staging(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            import agent
            old = (agent.ROOT, agent.SOCKET)
            agent.ROOT = root
            try:
                a = Agent()
                runtime = root / "runtime" / "rt" / "remotion-composer"
                (runtime / "render-tools").mkdir(parents=True)
                (runtime / "src").mkdir()
                (runtime / "node_modules").mkdir()
                (runtime / "package.json").write_text("{}")
                (runtime / "package-lock.json").write_text("{\"lockfileVersion\":3}")
                (runtime / "render-tools" / "render_chunks.mjs").write_text("openBrowser(\"chrome\", browserOptions)")
                job = a.job_root("overlay")
                (job / "input" / "props.json").write_text("{}")
                (job / "input" / "public").mkdir()
                overlay = job / "input" / "composer"
                (overlay / "render-tools").mkdir(parents=True)
                (overlay / "src").mkdir()
                (overlay / "package.json").write_text("{}")
                lock = overlay / "package-lock.json"
                lock.write_text(runtime.joinpath("package-lock.json").read_text())
                (overlay / "render-tools" / "render_chunks.mjs").write_text("openBrowser(\"chrome\", browserOptions); openBrowser(\"chrome\", browserOptions)")
                spec = {"propsPath": "props.json", "publicDir": "public", "workers": 32,
                        "lock_sha256": hashlib.sha256(lock.read_bytes()).hexdigest(),
                        "chunks": [{"out": "chunk.mp4", "from": 0, "to": 2}]}
                (job / "input" / "jobs.json").write_text(json.dumps(spec))
                resolved, info = a._validate_jobs("overlay", "rt", "jobs.json")
                self.assertEqual(resolved["workers"], 32)
                self.assertTrue(info and info["enabled"])
                staged, work = a._stage_composer("overlay", "rt", info)
                self.assertTrue((staged / "node_modules").is_symlink())
                self.assertIn("OM_RENDER_BROWSER_EXECUTABLE", (staged / "render-tools" / "render_chunks.mjs").read_text())
                self.assertTrue((work / "tmp").is_dir())
                self.assertEqual((staged / "render-tools" / "render_chunks.mjs").read_text().count("OM_RENDER_BROWSER_EXECUTABLE"), 2)
                lock.write_text('{"changed":true}')
                with self.assertRaisesRegex(RenderError, "deps_mismatch"):
                    a._validate_jobs("overlay", "rt", "jobs.json")
            finally:
                agent.ROOT, agent.SOCKET = old

    def test_manifest_and_incremental_logs(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            import agent
            old = (agent.ROOT, agent.SOCKET)
            agent.ROOT = root
            try:
                a = Agent()
                job = a.job_root("artifact")
                artifact = job / "output" / "clip.mp4"
                artifact.write_bytes(b"clip")
                a._write_manifest("artifact")
                manifest = json.loads((job / "output" / "manifest.json").read_text())
                self.assertEqual(manifest["files"][0]["path"], "clip.mp4")
                (job / "logs" / "render.log").write_text("abcdef", encoding="utf-8")
                part = a.logs("artifact", 2)
                self.assertEqual(part["log"], "cdef")
                self.assertEqual(part["next"], 6)
            finally:
                agent.ROOT, agent.SOCKET = old

    def test_canceled_queued_job_is_not_started_later(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            import agent
            old = (agent.ROOT, agent.SOCKET)
            agent.ROOT = root
            try:
                a = Agent()
                job = a.job_root("canceled")
                a.write_status("canceled", {
                    "state": "canceled", "job_id": "canceled", "runtime_id": "rt",
                    "resolved_jobs": str(job / "input" / "jobs.resolved.json"),
                })
                a.pending.put("canceled")
                with a.lock:
                    a._pump_locked()
                self.assertEqual(a.pending.qsize(), 0)
                self.assertEqual(a.read_status("canceled")["state"], "canceled")
            finally:
                agent.ROOT, agent.SOCKET = old


if __name__ == "__main__":
    unittest.main()
