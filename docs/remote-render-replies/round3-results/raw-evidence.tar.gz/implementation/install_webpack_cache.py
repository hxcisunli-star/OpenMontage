#!/usr/bin/env python3
"""Apply the service-owned cache path hook to an installed webpack runtime."""
import argparse
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("composer", type=Path)
args = parser.parse_args()
target = args.composer / "node_modules/webpack/lib/config/defaults.js"
source = target.read_text()
needle = 'F(cache, "cacheDirectory", () => {\n'
hook = '\t\t\t\tif (process.env.OM_RENDER_WEBPACK_CACHE) return path.resolve(process.env.OM_RENDER_WEBPACK_CACHE);\n'
if hook not in source:
    if source.count(needle) != 1:
        raise SystemExit("unsupported webpack cache layout; runtime unchanged")
    target.with_suffix(".js.om-original").write_text(source)
    target.write_text(source.replace(needle, needle + hook))
print(target, "cache hook installed")
