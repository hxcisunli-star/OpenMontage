#!/usr/bin/env python3
"""Install a checked, optional libx264 thread hook in CJS and ESM runtimes."""
import argparse
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('composer', type=Path)
args = parser.parse_args()
base = args.composer / 'node_modules/@remotion/renderer/dist'
edits = []
for name, needle, hook in [
    ('ffmpeg-args.js', "        ['-pix_fmt', pixelFormat],\n",
     "            process.env.OM_RENDER_FFMPEG_THREADS ? ['-threads', process.env.OM_RENDER_FFMPEG_THREADS] : null,\n"),
    ('esm/index.mjs', '    ["-pix_fmt", pixelFormat],\n',
     '    process.env.OM_RENDER_FFMPEG_THREADS ? ["-threads", process.env.OM_RENDER_FFMPEG_THREADS] : null,\n'),
]:
    target = base / name
    source = target.read_text()
    if hook in source:
        continue
    if source.count(needle) != 1:
        raise SystemExit(f'unsupported ffmpeg args layout: {target}; no new changes applied')
    edits.append((target, source, source.replace(needle, needle + hook)))
for target, source, changed in edits:
    backup = target.with_name(target.name + '.om-original')
    if not backup.exists():
        backup.write_text(source)
    target.write_text(changed)
print('CJS + ESM ffmpeg thread hook installed:', base)
