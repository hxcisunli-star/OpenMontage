#!/usr/bin/env python3
"""Run the supplied 144 kit through the actual service cgroup; keep raw evidence."""
import argparse
import concurrent.futures
import hashlib
import json
import math
import os
import pwd
import re
import signal
import shutil
import socket
import subprocess
import time
import urllib.request
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--name', required=True)
parser.add_argument('--workers', type=int, required=True)
parser.add_argument('--jobs', type=int, default=1)
parser.add_argument('--frames', type=int, default=300)
parser.add_argument('--start', type=int, default=3173)
parser.add_argument('--stills', action='store_true')
parser.add_argument('--quota', type=int, default=48)
parser.add_argument('--fail-worker', action='store_true', help='Kill one actual Node worker to check fast failure')
parser.add_argument('--keep', action='store_true', help='Keep completed jobs for remote polling; caller must clean up')
parser.add_argument('--balanced', action='store_true', help='Avoid a tiny final chunk by distributing frames evenly')
parser.add_argument('--render', default='{}', help='Whitelisted render profile JSON')
parser.add_argument('--tabs', type=int, default=2)
parser.add_argument('--ffmpeg-threads', type=int, choices=[1,2,4,8])
parser.add_argument('--v5-profile', action='store_true', help='Store under bench-v5 and sample CPU resources every second')
args = parser.parse_args()
root = Path('/srv/openmontage-render')
kit = root / 'bench-v4'
evidence = root / ('bench-v5' if args.v5_profile else 'bench-v4') / 'evidence' / args.name
evidence.mkdir(parents=True, exist_ok=False)

def call(op, **kw):
    with socket.socket(socket.AF_UNIX) as sock:
        sock.settimeout(15)
        sock.connect('/run/openmontage-render/agent.sock')
        sock.sendall((json.dumps(dict(op=op, **kw))+'\n').encode())
        with sock.makefile('rb') as stream:
            response = json.loads(stream.readline())
    if not response.get('ok'):
        raise RuntimeError(response)
    return response

def metrics(a, b, name, start_frame=None):
    stats = evidence / (name + '.psnr')
    graph = f'[0:v][1:v]psnr=stats_file={stats};[0:v][1:v]ssim'
    if start_frame is not None:
        graph = (f'[0:v]trim=start_frame={start_frame}:end_frame={start_frame+300},setpts=PTS-STARTPTS,split[a][b];'
                 f'[1:v]split[c][d];[a][c]psnr=stats_file={stats};[b][d]ssim')
    cmd = ['ffmpeg', '-v', 'info', '-threads', '2', '-i', str(a), '-threads', '2', '-i', str(b),
           '-filter_complex_threads', '2', '-lavfi', graph, '-f', 'null', '-']
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=180, check=True)
    (evidence / (name+'.metrics.log')).write_text(p.stderr)
    values = [float(x) for x in re.findall(r'psnr_avg:(\S+)', stats.read_text())]
    assert values, 'no comparison frames'
    ssim = float(re.search(r'SSIM.*All:([0-9.]+)', p.stderr)[1])
    return dict(min=min(values), avg=sum(values)/len(values), ssim=ssim, frames=len(values))

def health(port):
    t = time.monotonic()
    try:
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/queue', timeout=3) as r:
            d = json.load(r)
        return dict(port=port, ms=round((time.monotonic()-t)*1000,2), running=len(d.get('queue_running',[])), pending=len(d.get('queue_pending',[])))
    except Exception as e:
        return dict(port=port, error=str(e))

ids = []
specs = []
for j in range(args.jobs):
    ident = ('v5-' if args.v5_profile else 'v4-') + args.name + '-' + str(j)
    info = call('prepare', job_id=ident)
    dest = Path(info['input'])
    for name in ('composer', 'public'):
        shutil.copytree(kit/'input'/name, dest/name)
    shutil.copy2(kit/'input/props.json', dest/'props.json')
    if args.ffmpeg_threads is not None:
        script = dest/'composer/render-tools/render_chunks.mjs'
        script.write_text(f'process.env.OM_RENDER_FFMPEG_THREADS = "{args.ffmpeg_threads}";\n' + script.read_text())
    # Each job gets an equal share of the same total workload.
    a = args.start + args.frames*j//args.jobs
    b = args.start + args.frames*(j+1)//args.jobs
    size = math.ceil((b-a)/args.workers)
    chunks = [dict(out=f'p{i:03}.mp4', **{'from':s,'to':min(b-1,s+size-1)}) for i,s in enumerate(range(a,b,size))]
    if args.balanced:
        count = min(args.workers, b-a)
        chunks = [dict(out=f'p{i:03}.mp4', **{'from':a+(b-a)*i//count,'to':a+(b-a)*(i+1)//count-1}) for i in range(count)]
    stills = [dict(out=f'{n}.png',frame=round(t*30)) for n,t in
              {'t00060':6,'t01200':120,'t01533':153.3,'t01580':158,'t02908':290.8,'t03360':336}.items()] if args.stills and j==0 else []
    spec = dict(propsPath='props.json', publicDir='public',composition='Explainer', workers=args.workers, concurrency=args.tabs,
                timeoutMs=1800000,chunks=chunks,stills=stills)
    if json.loads(args.render): spec['render']=json.loads(args.render)
    (dest/'jobs.json').write_text(json.dumps(spec))
    account = pwd.getpwnam('openmontage-render')
    for p in dest.rglob('*'):
        os.chown(p, account.pw_uid, account.pw_gid)
    ids.append(ident); specs.append(spec)

started = time.monotonic()
while call('probe')['running'] or call('probe')['queued']:
    if time.monotonic()-started > 1800:
        raise RuntimeError('existing production jobs still active; benchmark not submitted')
    time.sleep(3)
started = time.monotonic()
subprocess.run(['systemctl','set-property','openmontage-render-agent.service',f'CPUQuota={args.quota*100}%'],check=True)
profiler = None
if args.v5_profile:
    from benchmark_v5 import Sampler
    profiler = Sampler(evidence/'telemetry.jsonl',args.name)
    profiler.start()
for ident in ids:
    call('submit', job_id=ident, runtime_id='om-20261007-remotion-v2', jobs_file='jobs.json')
cursors = dict.fromkeys(ids,0)
polls = 0
peak = 0
peak_tasks = 0
fault_at = None
foreign = set()
with (evidence/'poll.jsonl').open('w') as trace, concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    while True:
        loop = time.monotonic()
        statuses = [call('status',job_id=i) for i in ids]
        foreign.update(j for s in statuses for j in s.get('active_jobs', []) if j not in ids)
        if args.fail_worker and fault_at is None and time.monotonic()-started > 8:
            parent = statuses[0].get('pid')
            if parent:
                children = Path(f'/proc/{parent}/task/{parent}/children').read_text().split()
                for child in children:
                    if b'render_chunks.mjs' in Path(f'/proc/{child}/cmdline').read_bytes():
                        os.kill(int(child), signal.SIGKILL)
                        fault_at = time.monotonic()
                        (evidence/'fault.json').write_text(json.dumps(dict(pid=int(child),elapsed=fault_at-started)))
                        break
        for ident in ids:
            log = call('logs',job_id=ident,offset=cursors[ident]); cursors[ident]=log['next']
            with (evidence/(ident+'.log')).open('a') as f: f.write(log['log'])
        cg = subprocess.check_output(['systemctl','show','openmontage-render-agent.service','-p','MemoryCurrent','-p','TasksCurrent'],text=True)
        values = dict(l.split('=',1) for l in cg.splitlines())
        peak = max(peak,int(values['MemoryCurrent'])); peak_tasks=max(peak_tasks,int(values['TasksCurrent']))
        services=list(pool.map(health,[7865,7866,7867,7878]))
        trace.write(json.dumps(dict(elapsed=time.monotonic()-started,states=statuses,services=services,memory=int(values['MemoryCurrent']),tasks=int(values['TasksCurrent'])))+'\n');trace.flush()
        polls+=1
        if polls % 20 == 0:
            print(json.dumps(dict(name=args.name,elapsed=round(time.monotonic()-started),states=[s['state'] for s in statuses],peak_memory_mb=round(peak/1024**2),peak_tasks=peak_tasks)),flush=True)
        if all(s['state'] in ('completed','failed','canceled') for s in statuses): break
        if fault_at is not None and time.monotonic()-fault_at > 60:
            raise RuntimeError('worker failure did not become terminal within 60 seconds')
        if time.monotonic()-started>1800: raise RuntimeError('benchmark timed out; inspect original jobs')
        time.sleep(max(0,3-(time.monotonic()-loop)))
elapsed=time.monotonic()-started
if profiler: profiler.close()
if args.fail_worker:
    assert fault_at is not None and all(s['state']=='failed' for s in statuses), statuses
    report=dict(name=args.name,state='failed',seconds_after_fault=round(time.monotonic()-fault_at,3),statuses=statuses)
    (evidence/'result.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report),flush=True)
    for ident in ids: call('cleanup',job_id=ident)
    raise SystemExit(0)
assert all(s['state']=='completed' for s in statuses), statuses
outputs=[]
for ident,spec in zip(ids,specs):
    out=root/'jobs'/ident/'output'
    manifest=json.loads((out/'manifest.json').read_text())
    for entry in manifest['files']:
        p=out/entry['path']; assert p.stat().st_size==entry['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
    for item in spec['chunks']: outputs.append(out/item['out'])
    shutil.copy2(out/'manifest.json',evidence/(ident+'-manifest.json'))
    shutil.copytree(out,evidence/ident)
listing=evidence/'concat.txt'; listing.write_text(''.join(f"file '{p}'\n" for p in outputs))
joined=evidence/'joined.mp4'
subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(listing),'-c','copy',str(joined)],check=True)
execution = max(s['finished_at'] for s in statuses)-min(s['started_at'] for s in statuses)
report=dict(name=args.name,jobs=args.jobs,workers=args.workers,quota_cores=args.quota,frames=args.frames,seconds=round(execution,3),wall_seconds=round(elapsed,3),fps=round(args.frames/execution,2),peak_memory_mb=round(peak/1024**2),peak_tasks=peak_tasks,polls=polls)
report['tabs']=args.tabs
report['render']=json.loads(args.render)
report['ffmpeg_threads']=args.ffmpeg_threads
report['foreign_jobs']=sorted(foreign)
report['valid_performance_sample']=not foreign
report['stream']=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0',
    '-count_frames','-show_entries','stream=width,height,r_frame_rate,nb_frames,nb_read_frames,duration',
    '-of','json',str(joined)],text=True))
assert int(report['stream']['streams'][0]['nb_read_frames'])==args.frames
report['partition'] = 'balanced' if args.balanced else 'kit-ceil'
report['cache_files'] = sum(sum(1 for p in (root/'jobs'/i/'work/webpack-cache').rglob('*') if p.is_file()) for i in ids)
if args.frames==300 and args.start==3173:
    report['video']=metrics(joined,kit/'refs/ref_K4_3173-3472.mp4','video')
elif args.frames==11300 and args.start==0:
    report['video']=metrics(joined,kit/'refs/ref_K4_3173-3472.mp4','video',start_frame=3173)
if args.stills:
    report['stills']={p.stem:metrics(evidence/ids[0]/p.name,p,p.stem) for p in sorted((kit/'refs/stills').glob('*.png'))}
report['cache_eacces']=any('EACCES' in p.read_text() for p in evidence.glob('v?-*.log'))
report['worker_errors']=any(re.search(r'EAGAIN|EPIPE|Target closed|worker \d+ failed', p.read_text()) for p in evidence.glob('v?-*.log'))
report['pass'] = (not report['cache_eacces'] and report.get('video',{}).get('min',100)>=45
                  and not report['worker_errors']
                  and all(m['min']>=50 for m in report.get('stills',{}).values()))
(evidence/'result.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report),flush=True)
# Preserve evidence; remove only this benchmark's service jobs.
if not args.keep:
    for ident in ids: call('cleanup',job_id=ident)
