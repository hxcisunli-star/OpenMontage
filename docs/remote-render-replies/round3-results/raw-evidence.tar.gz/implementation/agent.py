#!/usr/bin/env python3
"""Small, local-only render agent for the OpenMontage reverse SSH link.

The agent accepts a line-delimited JSON protocol on a Unix socket.  It never
executes a command supplied by the caller: the only child it starts is the
versioned Remotion chunk renderer recorded in a runtime directory.
"""
from __future__ import annotations

import json
import hashlib
import os
import queue
import re
import shutil
import signal
import socket
import socketserver
import subprocess
import threading
import time
from pathlib import Path
from typing import Any


ROOT = Path(os.environ.get("OM_RENDER_ROOT", "/srv/openmontage-render"))
SOCKET = Path(os.environ.get("OM_RENDER_SOCKET", "/run/openmontage-render/agent.sock"))
NODE = os.environ.get("OM_RENDER_NODE", "/usr/bin/node")
AGENT_VERSION = "openmontage-render-agent/4"
JOB_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,95}$")
RUNTIME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,95}$")
REL_RE = re.compile(r"^[^\x00]+$")
MAX_JSON = 2 * 1024 * 1024
MAX_JOBS = 16
MAX_CHUNKS = 256
MAX_STILLS = 512
MAX_CONCURRENCY = 16
MAX_CONCURRENT_JOBS = 4
MAX_TOTAL_WORKERS = 32
MAX_WORKERS_PER_JOB = 32
MAX_TIMEOUT_MS = 8 * 60 * 60 * 1000
MIN_FREE_BYTES = 100 * 1024**3
AUTO_CLEAN_SECONDS = 6 * 60 * 60
MAX_LOG_BYTES = 256 * 1024
RUNTIME_PROFILE = {
    "gl": None,
    "chromeMode": "headless-shell",
    "tabs": 2,
    "hardwareAcceleration": "disabled",
    "videoBitrate": None,
    "x264Preset": None,
    "jpegQuality": None,
    "restartEvery": None,
}
TMP_MODE = {"disk", "shm"}
OVERLAY_DIRS = {"src", "render-tools", "render-fonts"}
OVERLAY_FILES = {"package.json", "package-lock.json", "tsconfig.json"}
RENDER_GL = {None, "angle", "egl", "swiftshader", "vulkan", "angle-egl", "swangle"}
RENDER_CHROME = {None, "headless-shell", "chrome-for-testing"}
RENDER_HW = {None, "disabled", "if-possible", "required"}


class RenderError(ValueError):
    pass


def now() -> float:
    return time.time()


def json_dump(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def job_id(value: Any) -> str:
    if not isinstance(value, str) or not JOB_RE.fullmatch(value):
        raise RenderError("invalid job_id")
    return value


def runtime_id(value: Any) -> str:
    if not isinstance(value, str) or not RUNTIME_RE.fullmatch(value):
        raise RenderError("invalid runtime_id")
    return value


def relative(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value or len(value) > 512 or not REL_RE.fullmatch(value):
        raise RenderError(f"invalid {label}")
    path = Path(value)
    if path.is_absolute() or ".." in path.parts:
        raise RenderError(f"{label} must stay relative")
    return path.as_posix()


def within(base: Path, value: str) -> Path:
    base = base.resolve()
    candidate = (base / value).resolve(strict=False)
    try:
        candidate.relative_to(base)
    except ValueError as exc:
        raise RenderError("path escapes job directory") from exc
    return candidate


def regular(path: Path, label: str) -> Path:
    if not path.is_file() or path.is_symlink():
        raise RenderError(f"{label} is not a regular file")
    return path


def directory(path: Path, label: str) -> Path:
    if not path.is_dir() or path.is_symlink():
        raise RenderError(f"{label} is not a regular directory")
    return path


def free_bytes(path: Path = ROOT) -> int:
    try:
        return shutil.disk_usage(path).free
    except OSError:
        return -1


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def tree_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    for item in sorted(path.rglob("*")):
        if item.is_symlink():
            raise RenderError("composer overlay contains a symlink")
        if item.is_file():
            digest.update(item.relative_to(path).as_posix().encode("utf-8"))
            digest.update(b"\0")
            digest.update(sha256_file(item).encode("ascii"))
            digest.update(b"\n")
    return digest.hexdigest()


def remove_tree(path: Path) -> None:
    if path.exists() or path.is_symlink():
        shutil.rmtree(path)


def _cpu_times() -> tuple[int, int]:
    values = [int(v) for v in Path('/proc/stat').read_text().splitlines()[0].split()[1:9]]
    return sum(values), values[3] + values[4]


def cpu_quota_cores() -> float | None:
    """Read the live systemd service quota on this host (cgroup v1)."""
    group = Path('/sys/fs/cgroup/cpu/system.slice/openmontage-render-agent.service')
    try:
        quota = int((group / 'cpu.cfs_quota_us').read_text())
        period = int((group / 'cpu.cfs_period_us').read_text())
        return quota / period if quota > 0 and period > 0 else None
    except (OSError, ValueError):
        return None


_cpu_sample = (0.0, 0, 0, 0)
_cpu_lock = threading.Lock()


def proc_load() -> tuple[int, int]:
    """CPU time utilization between probes, plus MemAvailable (not load average)."""
    global _cpu_sample
    try:
        with _cpu_lock:
            tick = time.monotonic()
            previous, total0, idle0, busy = _cpu_sample
            if tick-previous >= 0.25:
                # A first probe after a long idle period must not average that
                # whole idle period into the current utilization reading.
                if tick-previous > 5:
                    total0, idle0 = _cpu_times()
                    time.sleep(0.1)
                total, idle = _cpu_times()
                if total > total0:
                    busy = max(0, min(100, round(100*(1-(idle-idle0)/(total-total0)))))
                _cpu_sample = (time.monotonic(), total, idle, busy)
    except OSError:
        busy = 0
    available = 0
    try:
        for line in Path("/proc/meminfo").read_text(encoding="ascii").splitlines():
            if line.startswith("MemAvailable:"):
                available = int(line.split()[1]) // 1024
                break
    except (OSError, ValueError):
        pass
    return busy, available


def gpu_load() -> tuple[int, bool]:
    """Return max reported GPU utilization and whether another GPU process exists."""
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=utilization.gpu", "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=3, check=False,
        )
        values = [int(line.strip()) for line in result.stdout.splitlines() if line.strip().isdigit()]
        busy = max(values, default=0)
        apps = subprocess.run(
            ["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=3, check=False,
        )
        other = bool([line for line in apps.stdout.splitlines() if line.strip().isdigit()])
        return busy, other
    except (OSError, subprocess.SubprocessError, ValueError):
        return 0, False


class Agent:
    def __init__(self) -> None:
        self.lock = threading.RLock()
        self.pending: queue.Queue[str] = queue.Queue()
        self.processes: dict[str, subprocess.Popen[str]] = {}
        self.process_workers: dict[str, int] = {}
        self.cancelled: set[str] = set()
        self._ensure_layout()
        self._recover_stale()
        self._autoclean()

    @property
    def jobs_dir(self) -> Path:
        return ROOT / "jobs"

    @property
    def runtime_dir(self) -> Path:
        return ROOT / "runtime"

    def _ensure_layout(self) -> None:
        for path in (ROOT, self.jobs_dir, self.runtime_dir, ROOT / "home", ROOT / "fonts"):
            path.mkdir(parents=True, exist_ok=True)

    def _recover_stale(self) -> None:
        for state in self.jobs_dir.glob("*/state/status.json"):
            try:
                value = json.loads(state.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            if value.get("state") in {"queued", "running"}:
                self._cleanup_tmp(value)
                value.update({"state": "failed", "finished_at": now(), "error": "agent_restarted"})
                json_dump(state, value)

    def job_root(self, ident: str) -> Path:
        ident = job_id(ident)
        root = self.jobs_dir / ident
        root.mkdir(parents=True, exist_ok=True)
        for name in ("input", "output", "logs", "state"):
            (root / name).mkdir(exist_ok=True)
        return root

    def status_path(self, ident: str) -> Path:
        return self.jobs_dir / job_id(ident) / "state" / "status.json"

    def read_status(self, ident: str) -> dict[str, Any]:
        path = self.status_path(ident)
        if not path.exists():
            raise RenderError("unknown job")
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise RenderError("corrupt job status") from exc
        if not isinstance(value, dict):
            raise RenderError("corrupt job status")
        return value

    def write_status(self, ident: str, value: dict[str, Any]) -> None:
        json_dump(self.status_path(ident), value)

    def _runtime_lock(self, ident: str) -> Path:
        return self._runtime_composer(ident) / "package-lock.json"

    def _validate_overlay(self, root: Path, runtime: str) -> dict[str, Any] | None:
        overlay = root / "input" / "composer"
        if not overlay.exists():
            return None
        directory(overlay, "composer")
        for item in overlay.rglob("*"):
            if item.is_symlink():
                raise RenderError("composer overlay contains a symlink")
            relative_name = item.relative_to(overlay)
            top = relative_name.parts[0]
            if top not in OVERLAY_DIRS and top not in OVERLAY_FILES:
                raise RenderError(f"composer overlay contains unsupported path: {relative_name}")
            if item.is_file() and item.stat().st_size > 64 * 1024 * 1024:
                raise RenderError("composer overlay file is too large")
        for required in ("package.json", "package-lock.json", "render-tools/render_chunks.mjs", "src"):
            path = overlay / required
            if required == "src":
                directory(path, required)
            else:
                regular(path, required)
        runtime_lock = self._runtime_lock(runtime)
        overlay_lock = overlay / "package-lock.json"
        runtime_hash = sha256_file(runtime_lock)
        overlay_hash = sha256_file(overlay_lock)
        if overlay_hash != runtime_hash:
            raise RenderError("deps_mismatch")
        return {
            "enabled": True,
            "source_hash": tree_sha256(overlay),
            "lock_sha256": overlay_hash,
            "runtime_lock_sha256": runtime_hash,
        }

    def _validate_render(self, value: Any) -> dict[str, Any]:
        if value is None:
            return {}
        if not isinstance(value, dict):
            raise RenderError("render must be an object")
        allowed = {"gl", "chromeMode", "hardwareAcceleration", "videoBitrate", "x264Preset", "jpegQuality", "restartEvery"}
        unknown = set(value) - allowed
        if unknown:
            raise RenderError("unsupported render option")
        result = dict(value)
        if result.get("gl") not in RENDER_GL:
            raise RenderError("invalid render gl")
        if result.get("chromeMode") not in RENDER_CHROME:
            raise RenderError("invalid render chromeMode")
        if result.get("hardwareAcceleration") not in RENDER_HW:
            raise RenderError("invalid render hardwareAcceleration")
        for key in ("videoBitrate", "x264Preset"):
            if key in result and result[key] is not None and (not isinstance(result[key], str) or not re.fullmatch(r"[A-Za-z0-9._+-]{1,32}", result[key])):
                raise RenderError(f"invalid render {key}")
        for key in ("jpegQuality", "restartEvery"):
            if key in result and result[key] is not None and (isinstance(result[key], bool) or not isinstance(result[key], int) or result[key] < 1 or result[key] > 10000):
                raise RenderError(f"invalid render {key}")
        if result.get("hardwareAcceleration") not in (None, "disabled") and not result.get("videoBitrate"):
            raise RenderError("hardware acceleration requires videoBitrate")
        return result

    def _runtime_composer(self, ident: str) -> Path:
        root = self.runtime_dir / runtime_id(ident) / "remotion-composer"
        script = root / "render-tools" / "render_chunks.mjs"
        if not script.is_file() or not (root / "package.json").is_file():
            raise RenderError("runtime is not installed")
        return root

    def probe(self) -> dict[str, Any]:
        runtimes = []
        for path in sorted(self.runtime_dir.iterdir() if self.runtime_dir.exists() else []):
            if path.is_dir() and RUNTIME_RE.fullmatch(path.name) and (path / "remotion-composer" / "package.json").is_file():
                runtimes.append(path.name)
        with self.lock:
            running = list(self.processes)
            pending = self.pending.qsize()
            used_workers = sum(self.process_workers.values())
        cpu_busy, mem_free = proc_load()
        gpu_busy, other_gpu = gpu_load()
        default_runtime = "om-20261007-remotion-v2" if (self.runtime_dir / "om-20261007-remotion-v2").exists() else (runtimes[-1] if runtimes else None)
        lock_sha = None
        chrome_version = None
        if default_runtime:
            try:
                lock_sha = sha256_file(self._runtime_lock(default_runtime))
            except (OSError, RenderError):
                pass
        try:
            browser = os.environ.get("OM_RENDER_BROWSER_EXECUTABLE")
            if browser:
                version = subprocess.run([browser, "--version"], capture_output=True, text=True, timeout=5, check=False)
                chrome_version = version.stdout.strip() or version.stderr.strip()
        except (OSError, subprocess.SubprocessError):
            pass
        return {
            "ok": True,
            "agent": AGENT_VERSION,
            "socket": str(SOCKET),
            "root": str(ROOT),
            "node": NODE,
            "runtimes": runtimes,
            "running": running,
            "queued": pending,
            "features": ["src_overlay", "fontconfig_self_managed", "manifest", "log_offset", "multi_queue"],
            "chrome_version": chrome_version,
            "runtime_lock_sha256": lock_sha,
            "render_profile": dict(RUNTIME_PROFILE),
            "capacity": {
                "max_concurrent_jobs": MAX_CONCURRENT_JOBS,
                "max_total_workers": MAX_TOTAL_WORKERS,
                "recommended_workers_per_job": 8,
            },
            "load": {
                "cpu_busy_percent": cpu_busy,
                "mem_free_mb": mem_free,
                "gpu_busy_percent": gpu_busy,
                "other_gpu_jobs_running": other_gpu,
                "active_workers": used_workers,
            },
            "limits": {"max_queue": MAX_JOBS, "max_job_seconds": MAX_TIMEOUT_MS // 1000,
                       "cpu_quota_cores": cpu_quota_cores()},
            "runtime_settings": {"tmp_mode": os.environ.get('OM_RENDER_TMP_MODE', 'disk'),
                                 "ffmpeg_threads": os.environ.get('OM_RENDER_FFMPEG_THREADS') or 'auto'},
            "max_concurrent": MAX_CONCURRENT_JOBS,
            "max_concurrency": MAX_CONCURRENCY,
            "free_bytes": free_bytes(),
            "min_free_bytes": MIN_FREE_BYTES,
        }

    def prepare(self, ident: str) -> dict[str, Any]:
        ident = job_id(ident)
        root = self.job_root(ident)
        with self.lock:
            if ident in self.processes:
                raise RenderError("job is running")
            old = root / "state" / "status.json"
            if old.exists():
                raise RenderError("job already exists; cleanup first")
        return {"ok": True, "job_id": ident, "input": str(root / "input"), "output": str(root / "output")}

    def _validate_jobs(self, ident: str, runtime: str, jobs_file: str) -> tuple[dict[str, Any], dict[str, Any] | None]:
        root = self.job_root(ident)
        input_root = directory(root / "input", "input")
        output_root = directory(root / "output", "output")
        source = regular(within(input_root, relative(jobs_file, "jobs_file")), "jobs_file")
        if source.stat().st_size > MAX_JSON:
            raise RenderError("jobs_file is too large")
        try:
            jobs = json.loads(source.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise RenderError("jobs_file is not valid JSON") from exc
        if not isinstance(jobs, dict):
            raise RenderError("jobs_file must be an object")
        composer = self._runtime_composer(runtime)
        overlay = self._validate_overlay(root, runtime)
        props = regular(within(input_root, relative(jobs.get("propsPath"), "propsPath")), "propsPath")
        public = directory(within(input_root, relative(jobs.get("publicDir"), "publicDir")), "publicDir")
        composition = jobs.get("composition", "Explainer")
        if not isinstance(composition, str) or not re.fullmatch(r"[A-Za-z0-9_.-]{1,80}", composition):
            raise RenderError("invalid composition")
        concurrency = jobs.get("concurrency", 4)
        workers = jobs.get("workers", 1)
        timeout = jobs.get("timeoutMs", 7_200_000)
        if isinstance(concurrency, bool) or not isinstance(concurrency, int) or not 1 <= concurrency <= MAX_CONCURRENCY:
            raise RenderError("invalid concurrency")
        if isinstance(workers, bool) or not isinstance(workers, int) or not 1 <= workers <= MAX_WORKERS_PER_JOB:
            raise RenderError("invalid workers")
        if isinstance(timeout, bool) or not isinstance(timeout, int) or not 1_000 <= timeout <= MAX_TIMEOUT_MS:
            raise RenderError("invalid timeoutMs")
        chunks = jobs.get("chunks") or []
        stills = jobs.get("stills") or []
        if not isinstance(chunks, list) or not isinstance(stills, list) or len(chunks) > MAX_CHUNKS or len(stills) > MAX_STILLS:
            raise RenderError("too many render items")
        resolved: dict[str, Any] = {
            "propsPath": str(props), "publicDir": str(public), "composition": composition,
            "concurrency": concurrency, "workers": workers, "timeoutMs": timeout, "chunks": [], "stills": [],
            "infoOut": str(output_root / "composition.json"),
        }
        render = self._validate_render(jobs.get("render"))
        if render:
            resolved["render"] = render
        if jobs.get("composer_hash") is not None:
            if not isinstance(jobs.get("composer_hash"), str) or not re.fullmatch(r"[0-9a-fA-F]{64}", jobs["composer_hash"]):
                raise RenderError("invalid composer_hash")
            resolved["composer_hash"] = jobs["composer_hash"]
        if jobs.get("lock_sha256") is not None:
            lock_sha = jobs["lock_sha256"]
            if not isinstance(lock_sha, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", lock_sha):
                raise RenderError("invalid lock_sha256")
            if overlay and lock_sha.lower() != overlay["lock_sha256"]:
                raise RenderError("deps_mismatch")
            resolved["lock_sha256"] = lock_sha
        names: set[str] = set()
        for item in chunks:
            if not isinstance(item, dict):
                raise RenderError("invalid chunk")
            out = relative(item.get("out"), "chunk out")
            target = within(output_root, out)
            if str(target) in names:
                raise RenderError("duplicate output")
            names.add(str(target))
            start, end = item.get("from"), item.get("to")
            if isinstance(start, bool) or isinstance(end, bool) or not isinstance(start, int) or not isinstance(end, int) or start < 0 or end < start:
                raise RenderError("invalid chunk frame range")
            resolved["chunks"].append({"out": str(target), "from": start, "to": end})
        for item in stills:
            if not isinstance(item, dict):
                raise RenderError("invalid still")
            out = relative(item.get("out"), "still out")
            target = within(output_root, out)
            if str(target) in names:
                raise RenderError("duplicate output")
            names.add(str(target))
            frame = item.get("frame")
            if isinstance(frame, bool) or not isinstance(frame, int) or frame < 0:
                raise RenderError("invalid still frame")
            resolved["stills"].append({"out": str(target), "frame": frame})
        if not resolved["chunks"] and not resolved["stills"]:
            raise RenderError("no render items")
        return resolved, overlay

    def _stage_composer(self, ident: str, runtime: str, overlay: dict[str, Any] | None) -> tuple[Path, Path]:
        root = self.job_root(ident)
        work = root / "work"
        if work.exists():
            remove_tree(work)
        work.mkdir(parents=True)
        tmp = work / "tmp"
        tmp.mkdir()
        if not overlay:
            return self._runtime_composer(runtime), work
        source = root / "input" / "composer"
        destination = work / "composer"
        destination.mkdir()
        for name in sorted(OVERLAY_DIRS | OVERLAY_FILES):
            item = source / name
            if not item.exists():
                continue
            target = destination / name
            if item.is_dir():
                shutil.copytree(item, target, symlinks=False)
            else:
                shutil.copy2(item, target)
        runtime_node_modules = self._runtime_composer(runtime) / "node_modules"
        if not runtime_node_modules.is_dir():
            raise RenderError("runtime node_modules is missing")
        (destination / "node_modules").symlink_to(runtime_node_modules, target_is_directory=True)
        # The v3 overlay leaves browser selection to the machine.  Add only
        # the platform executable hook; source, props and render semantics stay
        # in the uploaded overlay.
        script = destination / "render-tools" / "render_chunks.mjs"
        source_text = script.read_text(encoding="utf-8")
        if "OM_RENDER_BROWSER_EXECUTABLE" not in source_text:
            source_text = source_text.replace(
                'openBrowser("chrome", browserOptions)',
                'openBrowser("chrome", { ...browserOptions, browserExecutable: process.env.OM_RENDER_BROWSER_EXECUTABLE || undefined })',
            )
            source_text = source_text.replace(
                'openBrowser("chrome", { chromiumOptions: {} })',
                'openBrowser("chrome", { browserExecutable: process.env.OM_RENDER_BROWSER_EXECUTABLE || undefined, chromiumOptions: {} })',
                1,
            )
            script.write_text(source_text, encoding="utf-8")
        return destination, work

    def _select_tmp_dir(self, ident: str, work: Path) -> Path:
        """Select a private frame/ffmpeg scratch directory.

        The default remains the job's ext4 work directory.  ``shm`` is a
        service-only experiment; it falls back before starting a child when
        the private tmpfs has less than 20 GiB free.
        """
        mode = os.environ.get("OM_RENDER_TMP_MODE", "disk")
        disk_tmp = work / "tmp"
        if mode not in TMP_MODE or mode == "disk":
            return disk_tmp
        candidate = Path("/dev/shm/openmontage-render") / ident
        try:
            candidate.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            if shutil.disk_usage(candidate.parent).free < 20 * 1024**3:
                return disk_tmp
            remove_tree(candidate)
            candidate.mkdir(mode=0o700)
            return candidate
        except OSError:
            return disk_tmp

    @staticmethod
    def _cleanup_tmp(status: dict[str, Any]) -> None:
        value = status.get("tmp_dir")
        if isinstance(value, str):
            path = Path(value)
            if path.parent == Path('/dev/shm/openmontage-render') and JOB_RE.fullmatch(path.name):
                remove_tree(path)

    def submit(self, ident: str, runtime: str, jobs_file: str) -> dict[str, Any]:
        ident = job_id(ident)
        resolved, overlay = self._validate_jobs(ident, runtime, jobs_file)
        root = self.job_root(ident)
        resolved_path = root / "input" / "jobs.resolved.json"
        json_dump(resolved_path, resolved)
        with self.lock:
            existing = self.read_status(ident) if (root / "state" / "status.json").exists() else None
            if existing and existing.get("state") in {"queued", "running"}:
                raise RenderError("job already active")
            if self.pending.qsize() >= MAX_JOBS:
                raise RenderError("queue full")
            status = {
                "ok": True, "job_id": ident, "runtime_id": runtime, "state": "queued",
                "submitted_at": now(), "started_at": None, "finished_at": None,
                "progress": 0.0, "pid": None, "error": None,
                "jobs_file": jobs_file, "resolved_jobs": str(resolved_path),
                "workers": resolved["workers"], "concurrency": resolved["concurrency"],
                "source_overlay": bool(overlay), "overlay": overlay,
                "downloaded_at": None, "queue_position": self.pending.qsize() + 1,
            }
            self.write_status(ident, status)
            self.pending.put(ident)
            self._pump_locked()
            return status

    def _pump_locked(self) -> None:
        if len(self.processes) >= MAX_CONCURRENT_JOBS:
            return
        candidates = []
        while True:
            try:
                candidates.append(self.pending.get_nowait())
            except queue.Empty:
                break
        used_workers = sum(self.process_workers.values())
        selected = None
        deferred = []
        for candidate in candidates:
            try:
                candidate_status = self.read_status(candidate)
            except RenderError:
                continue
            if candidate_status.get("state") != "queued":
                self.cancelled.discard(candidate)
                continue
            requested_workers = int(candidate_status.get("workers", 1))
            if selected is None and used_workers + requested_workers <= MAX_TOTAL_WORKERS:
                selected = (candidate, candidate_status)
            else:
                deferred.append(candidate)
        for candidate in deferred:
            self.pending.put(candidate)
        if selected is None:
            return
        ident, status = selected
        if free_bytes() >= 0 and free_bytes() < MIN_FREE_BYTES:
            status.update({"state": "failed", "finished_at": now(), "error": "disk_free_below_floor"})
            self.write_status(ident, status)
            self._pump_locked()
            return
        root = self.job_root(ident)
        runtime = runtime_id(status["runtime_id"])
        log = None
        tmp_dir = None
        try:
            composer, work = self._stage_composer(ident=ident, runtime=runtime, overlay=status.get("overlay"))
            tmp_dir = self._select_tmp_dir(ident, work)
            log_path = root / "logs" / "render.log"
            log = log_path.open("a", encoding="utf-8")
            requested_tmp = os.environ.get('OM_RENDER_TMP_MODE', 'disk')
            selected_tmp = 'shm' if tmp_dir.parent == Path('/dev/shm/openmontage-render') else 'disk'
            log.write(f'@@scratch requested={requested_tmp} selected={selected_tmp} path={tmp_dir}'
                      + (' fallback=unavailable_or_less_than_20GiB_free' if requested_tmp == 'shm' and selected_tmp == 'disk' else '') + '\n')
            log.flush()
            child_env = {
                k: v for k, v in os.environ.items()
                if k not in {"FONTCONFIG_FILE", "FONTCONFIG_PATH"} and not k.startswith("FC_")
            }
            child_env.update({
                "HOME": str(ROOT / "home"), "TMPDIR": str(tmp_dir), "LANG": "C.UTF-8",
                "OM_RENDER_WEBPACK_CACHE": str(work / "webpack-cache"),
                "OM_RENDER_FFMPEG_THREADS": os.environ.get("OM_RENDER_FFMPEG_THREADS", ""),
                "NODE_NO_WARNINGS": "1", "OM_RENDER_BROWSER_EXECUTABLE": os.environ.get("OM_RENDER_BROWSER_EXECUTABLE", ""),
            })
            process = subprocess.Popen(
                [NODE, str(composer / "render-tools" / "render_chunks.mjs"), status["resolved_jobs"]],
                cwd=str(composer), stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, bufsize=1, start_new_session=True, env=child_env,
            )
        except (OSError, RenderError) as exc:
            if log is not None:
                log.close()
            if tmp_dir is not None and tmp_dir != work / "tmp":
                remove_tree(tmp_dir)
            status.update({"state": "failed", "finished_at": now(), "error": str(exc)[:300]})
            self.write_status(ident, status)
            self._pump_locked()
            return
        status.update({"state": "running", "started_at": now(), "pid": process.pid, "work_dir": str(work),
                       "tmp_dir": str(tmp_dir), "queue_position": None})
        self.processes[ident] = process
        self.process_workers[ident] = int(status.get("workers", 1))
        self.write_status(ident, status)
        threading.Thread(target=self._watch, args=(ident, process, log), daemon=True).start()
        self._pump_locked()

    def _watch(self, ident: str, process: subprocess.Popen[str], log: Any) -> None:
        worker_failure = None
        try:
            for line in process.stdout or ():
                log.write(line)
                log.flush()
                # The uploaded parent can hang in Promise.all after a worker
                # fails. Its explicit failure record is terminal, even while
                # other children still hold stdout open.
                if worker_failure is None and re.fullmatch(r"worker \d+ failed \(exit (?:-?\d+|null)\)", line.strip()):
                    worker_failure = line.strip()
                    try:
                        os.killpg(process.pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
                    threading.Thread(target=self._kill_after_timeout, args=(ident, process), daemon=True).start()
                progress = re.search(r"@@progress\s+\S+\s+(\d+)\s+(\d+)", line)
                match = re.search(r"\b(\d{1,3})%", line)
                if progress or match:
                    with self.lock:
                        try:
                            status = self.read_status(ident)
                            if progress:
                                done, total = int(progress.group(1)), max(1, int(progress.group(2)))
                                status["progress"] = max(float(status.get("progress", 0.0)), min(1.0, done / total))
                            elif match:
                                status["progress"] = max(0.0, min(1.0, int(match.group(1)) / 100.0))
                            self.write_status(ident, status)
                        except RenderError:
                            pass
            code = process.wait()
        finally:
            if process.stdout is not None:
                process.stdout.close()
            log.close()
        with self.lock:
            cancelled = ident in self.cancelled
            self.cancelled.discard(ident)
            self.processes.pop(ident, None)
            self.process_workers.pop(ident, None)
            try:
                status = self.read_status(ident)
                if cancelled:
                    self._clear_output(ident)
                    status.update({"state": "canceled", "error": "canceled", "progress": status.get("progress", 0.0)})
                elif worker_failure:
                    status.update({"state": "failed", "error": worker_failure})
                elif code == 0:
                    self._write_manifest(ident)
                    status.update({"state": "completed", "progress": 1.0, "error": None})
                else:
                    status.update({"state": "failed", "error": f"render_exit:{code}"})
                status.update({"finished_at": now(), "pid": None})
                self._cleanup_tmp(status)
                self.write_status(ident, status)
            except (RenderError, OSError) as exc:
                try:
                    status = self.read_status(ident)
                    status.update({"state": "failed", "finished_at": now(), "pid": None, "error": str(exc)[:300]})
                    self.write_status(ident, status)
                except RenderError:
                    pass
            self._pump_locked()

    def _clear_output(self, ident: str) -> None:
        output = self.jobs_dir / job_id(ident) / "output"
        if not output.exists():
            return
        for item in output.iterdir():
            if item.is_dir() and not item.is_symlink():
                shutil.rmtree(item)
            elif item.is_symlink() or item.is_file():
                item.unlink()

    def _write_manifest(self, ident: str) -> None:
        output = self.jobs_dir / job_id(ident) / "output"
        entries = []
        for item in sorted(output.rglob("*")):
            if item.name == "manifest.json" or item.is_symlink() or not item.is_file():
                continue
            entries.append({"path": item.relative_to(output).as_posix(), "bytes": item.stat().st_size, "sha256": sha256_file(item)})
        json_dump(output / "manifest.json", {"files": entries})

    def _queue_position(self, ident: str) -> int | None:
        with self.pending.mutex:
            queued = list(self.pending.queue)
        position = 0
        for candidate in queued:
            try:
                state = self.read_status(candidate).get("state")
            except RenderError:
                continue
            if state != "queued":
                continue
            position += 1
            if candidate == ident:
                return position
        return None

    def _autoclean(self) -> None:
        cutoff = now() - AUTO_CLEAN_SECONDS
        for state_path in self.jobs_dir.glob("*/state/status.json"):
            ident = state_path.parents[1].name
            if ident in self.processes:
                continue
            try:
                status = json.loads(state_path.read_text(encoding="utf-8"))
                finished = float(status.get("finished_at") or 0)
                downloaded = float(status.get("downloaded_at") or 0)
            except (OSError, ValueError, TypeError):
                continue
            if status.get("state") in {"completed", "failed", "canceled"} and finished < cutoff and (not downloaded or downloaded < cutoff):
                shutil.rmtree(self.jobs_dir / ident, ignore_errors=True)

    def status(self, ident: str) -> dict[str, Any]:
        ident = job_id(ident)
        self._autoclean()
        with self.lock:
            status = self.read_status(ident)
            if status.get("state") == "queued":
                status["queue_position"] = self._queue_position(ident)
            status["active_jobs"] = list(self.processes)
            return status

    def cancel(self, ident: str) -> dict[str, Any]:
        ident = job_id(ident)
        with self.lock:
            process = self.processes.get(ident)
            if process is None:
                status = self.read_status(ident)
                if status.get("state") == "queued":
                    self.cancelled.add(ident)
                    status.update({"state": "canceled", "finished_at": now(), "error": "canceled"})
                    self.write_status(ident, status)
                    return status
                return status
            self.cancelled.add(ident)
            status = self.read_status(ident)
            if status.get("state") != "canceling":
                status.update({"state": "canceling", "cancel_requested_at": now()})
                self.write_status(ident, status)
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            threading.Thread(target=self._kill_after_timeout, args=(ident, process), daemon=True).start()
            return {"ok": True, "job_id": ident, "state": "canceling"}

    def _kill_after_timeout(self, ident: str, process: subprocess.Popen[str]) -> None:
        if process.poll() is not None:
            return
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline and process.poll() is None:
            time.sleep(0.25)
        if process.poll() is None:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass

    def cleanup(self, ident: str) -> dict[str, Any]:
        ident = job_id(ident)
        with self.lock:
            if ident in self.processes:
                raise RenderError("job is running")
            root = self.jobs_dir / ident
            if not root.exists():
                raise RenderError("unknown job")
            shutil.rmtree(root)
            return {"ok": True, "job_id": ident, "state": "removed"}

    def downloaded(self, ident: str) -> dict[str, Any]:
        ident = job_id(ident)
        with self.lock:
            status = self.read_status(ident)
            status["downloaded_at"] = now()
            self.write_status(ident, status)
            return {"ok": True, "job_id": ident, "downloaded_at": status["downloaded_at"]}

    def logs(self, ident: str, offset: Any = 0) -> dict[str, Any]:
        ident = job_id(ident)
        if isinstance(offset, bool) or not isinstance(offset, int) or offset < 0:
            raise RenderError("invalid log offset")
        path = self.jobs_dir / ident / "logs" / "render.log"
        if not path.exists():
            raise RenderError("job log unavailable")
        with path.open("rb") as handle:
            handle.seek(offset)
            data = handle.read(MAX_LOG_BYTES)
            next_offset = handle.tell()
        return {"ok": True, "job_id": ident, "log": data.decode("utf-8", "replace"), "next": next_offset}

    def request(self, req: Any) -> dict[str, Any]:
        if not isinstance(req, dict):
            raise RenderError("request must be an object")
        op = req.get("op")
        if op == "probe":
            return self.probe()
        if op == "prepare":
            return self.prepare(req.get("job_id"))
        if op == "submit":
            return self.submit(req.get("job_id"), req.get("runtime_id"), req.get("jobs_file"))
        if op == "status":
            return self.status(req.get("job_id"))
        if op == "cancel":
            return self.cancel(req.get("job_id"))
        if op == "cleanup":
            return self.cleanup(req.get("job_id"))
        if op == "downloaded":
            return self.downloaded(req.get("job_id"))
        if op == "logs":
            return self.logs(req.get("job_id"), req.get("offset", 0))
        raise RenderError("unsupported operation")


class Handler(socketserver.StreamRequestHandler):
    def handle(self) -> None:
        line = self.rfile.readline(MAX_JSON + 1)
        if len(line) > MAX_JSON:
            self._reply({"ok": False, "error": "request too large"})
            return
        try:
            request = json.loads(line.decode("utf-8"))
            result = self.server.agent.request(request)  # type: ignore[attr-defined]
            self._reply(result)
        except (UnicodeDecodeError, ValueError, RenderError, OSError) as exc:
            self._reply({"ok": False, "error": str(exc)[:300]})

    def _reply(self, value: dict[str, Any]) -> None:
        self.wfile.write((json.dumps(value, ensure_ascii=False) + "\n").encode("utf-8"))
        self.wfile.flush()


class UnixServer(socketserver.ThreadingMixIn, socketserver.UnixStreamServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address: str, agent: Agent) -> None:
        self.agent = agent
        super().__init__(address, Handler)


def main() -> int:
    SOCKET.parent.mkdir(parents=True, exist_ok=True)
    try:
        SOCKET.unlink()
    except FileNotFoundError:
        pass
    agent = Agent()
    server = UnixServer(str(SOCKET), agent)
    os.chmod(SOCKET, 0o660)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        try:
            SOCKET.unlink()
        except FileNotFoundError:
            pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
