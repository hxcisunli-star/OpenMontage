#!/usr/bin/env python3
"""Summarize retained v5 per-second observations, including failed experiments."""
import json
import re
import statistics
from pathlib import Path

root=Path('/srv/openmontage-render/bench-v5/evidence')
all_results=[]
for p in sorted(root.iterdir()):
    if not p.is_dir() or not (p/'result.json').exists():
        continue
    r=json.loads((p/'result.json').read_text())
    rows=[json.loads(l) for l in (p/'telemetry.jsonl').read_text().splitlines()]
    if 'timing' in r and (p/'render.log').exists():
        # Correct early collection labels without overwriting raw result.json.
        r['timing']['chunk_done_seconds']=[float(m[1]) for line in (p/'render.log').read_text().splitlines()
            if line.startswith('chunk ') and (m:=re.search(r' done ([0-9.]+)s$',line))]
        r['peak_tasks']=max(sum(g['threads'] for g in x['processes']['groups'].values()) for x in rows)
    steady=[x for x in rows if x['elapsed']>10] or rows
    core=[sum(x['cpu_percent'].values())/100 for x in steady]
    intervals=[b['elapsed']-a['elapsed'] for a,b in zip(rows,rows[1:])]
    full_time=sum(intervals) or 1
    throttle=sum(x['cgroup_cpu_stat'].get('nr_throttled',0) for x in rows)
    periods=sum(x['cgroup_cpu_stat'].get('nr_periods',0) for x in rows)
    usage=sum(x.get('cgroup_usage_ns',0) for x in rows)/1e9/full_time
    perf={}
    for x in steady:
        for k,v in x.get('perf_delta',{}).items():perf[k]=perf.get(k,0)+v
    duration=sum(b['elapsed']-a['elapsed'] for a,b in zip(rows,rows[1:]) if b['elapsed']>10) or full_time
    ffmpeg=[v for x in steady for v in x['processes']['processes'] if v['kind']=='ffmpeg']
    browser=[v for x in steady for v in x['processes']['processes'] if v['kind']=='chrome']
    images={}
    for x in rows:
        for v in x.get('image_processes',[]):
            pid=str(v['pid'])
            if pid not in images:images[pid]={'first':v['cpu_ticks'],'last':v['cpu_ticks'],'executable':v['executable']}
            images[pid]['last']=v['cpu_ticks']
    stats={
        'cpu_mean_cores':round(statistics.mean(core),2),
        'cgroup_mean_cores':round(usage,2) if usage else None,
        'full_core_seconds':round(sum(sum(v>=95 for v in b['cpu_percent'].values())*(b['elapsed']-a['elapsed']) for a,b in zip(rows,rows[1:]) if b['elapsed']>10),2),
        'cgroup_peak_cores':round(max((x.get('cgroup_usage_ns',0)/1e9 for x in rows),default=0),2),
        'iowait_mean_percent':round(statistics.mean(x.get('iowait_percent',0) for x in rows),4),
        'iowait_max_percent':round(max(x.get('iowait_percent',0) for x in rows),4),
        'throttled_period_fraction':round(throttle/max(periods,1),4),
        'throttled_time_ns':sum(x['cgroup_cpu_stat'].get('throttled_time',0) for x in rows),
        'memory_bandwidth_gib_s':round((perf.get('memory_read_mib',0)+perf.get('memory_write_mib',0))/duration/1024,3) if 'memory_read_mib' in perf else None,
        'ipc':round(perf.get('instructions',0)/max(perf.get('cycles',1),1),3) if perf else None,
        'cache_miss_ratio':round(perf.get('cache_misses',0)/max(perf.get('cache_references',1),1),3) if perf else None,
        'ffmpeg_threads_max':max((x['threads'] for x in ffmpeg),default=0),
        'ffmpeg_threads_median':statistics.median(x['threads'] for x in ffmpeg) if ffmpeg else 0,
        'chrome_threads_max_per_process':max((x['threads'] for x in browser),default=0),
        'cgroup_memory_peak_mib':round(max((x.get('cgroup_memory_bytes',0) for x in rows),default=0)/2**20) or None,
        'image_service_cpu_cores':{pid:round((v['last']-v['first'])/100/full_time,4) for pid,v in images.items()},
        'sample_interval_max':round(max(intervals),3) if intervals else None,
        'sample_interval_median':round(statistics.median(intervals),3) if intervals else None,
    }
    r['resource_summary']=stats
    (p/'summary.json').write_text(json.dumps(r,indent=2)+'\n')
    all_results.append(r)
    print(r['name'],r['seconds'],'s',r['fps'],'fps',stats)
(root/'summaries.json').write_text(json.dumps(all_results,indent=2)+'\n')
