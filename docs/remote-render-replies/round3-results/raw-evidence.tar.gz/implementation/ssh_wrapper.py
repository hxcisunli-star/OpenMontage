#!/usr/bin/env python3
"""Forced-command boundary for the local ``openmontage-render`` account."""
from __future__ import annotations

import json
import os
import re
import shlex
import socket
import sys
import tarfile
import tempfile
from pathlib import Path


ROOT = Path(os.environ.get("OM_RENDER_ROOT", "/srv/openmontage-render"))
SOCKET = os.environ.get("OM_RENDER_SOCKET", "/run/openmontage-render/agent.sock")
JOB_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,95}$")
MAX_ARCHIVE_BYTES = 48 * 1024**3
MAX_MEMBERS = 20_000


def ident(value: str) -> str:
    if not JOB_RE.fullmatch(value):
        raise ValueError("invalid job_id")
    return value


def call(payload: dict) -> dict:
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as sock:
        sock.settimeout(30)
        sock.connect(SOCKET)
        sock.sendall((json.dumps(payload, ensure_ascii=False) + "\n").encode())
        data = b""
        while not data.endswith(b"\n"):
            chunk = sock.recv(65536)
            if not chunk:
                break
            data += chunk
            if len(data) > 2 * 1024 * 1024:
                raise ValueError("agent response too large")
    if not data:
        raise ValueError("agent unavailable")
    result = json.loads(data.decode())
    if not isinstance(result, dict):
        raise ValueError("invalid agent response")
    return result


def reply(result: dict) -> int:
    sys.stdout.write(json.dumps(result, ensure_ascii=False) + "\n")
    return 0 if result.get("ok", False) else 1


def safe_member(name: str) -> Path:
    path = Path(name)
    if path.is_absolute() or ".." in path.parts or name in {"", "."}:
        raise ValueError("archive path escapes input")
    return path


def upload(job: str) -> int:
    job = ident(job)
    result = call({"op": "prepare", "job_id": job})
    if not result.get("ok"):
        return reply(result)
    job_root = ROOT / "jobs" / job
    staging = Path(tempfile.mkdtemp(prefix=".upload-", dir=job_root))
    total = 0
    try:
        with tarfile.open(fileobj=sys.stdin.buffer, mode="r|*") as archive:
            for count, member in enumerate(archive, 1):
                if count > MAX_MEMBERS:
                    raise ValueError("too many archive members")
                rel = safe_member(member.name)
                target = (staging / rel).resolve(strict=False)
                if staging.resolve() not in target.parents and target != staging.resolve():
                    raise ValueError("archive path escapes staging")
                if member.isdir():
                    target.mkdir(parents=True, exist_ok=True)
                elif member.isfile():
                    total += int(member.size)
                    if total > MAX_ARCHIVE_BYTES:
                        raise ValueError("archive is too large")
                    target.parent.mkdir(parents=True, exist_ok=True)
                    source = archive.extractfile(member)
                    if source is None:
                        raise ValueError("archive member has no data")
                    with target.open("wb") as output:
                        while True:
                            block = source.read(1024 * 1024)
                            if not block:
                                break
                            output.write(block)
                    os.chmod(target, 0o640)
                else:
                    raise ValueError("archive contains a non-regular member")
        input_dir = job_root / "input"
        backup = job_root / ".input.previous"
        if backup.exists():
            import shutil
            shutil.rmtree(backup)
        if input_dir.exists():
            input_dir.rename(backup)
        staging.rename(input_dir)
        if backup.exists():
            import shutil
            shutil.rmtree(backup)
        return reply({"ok": True, "job_id": job, "bytes": total})
    except Exception as exc:
        import shutil
        shutil.rmtree(staging, ignore_errors=True)
        return reply({"ok": False, "error": str(exc)[:300]})


def download(job: str) -> int:
    job = ident(job)
    result = call({"op": "status", "job_id": job})
    if not result.get("ok"):
        return reply(result)
    output = ROOT / "jobs" / job / "output"
    if not output.is_dir() or output.is_symlink():
        return reply({"ok": False, "error": "output unavailable"})
    marked = call({"op": "downloaded", "job_id": job})
    if not marked.get("ok"):
        return reply(marked)
    with tarfile.open(fileobj=sys.stdout.buffer, mode="w|", format=tarfile.PAX_FORMAT) as archive:
        for path in sorted(output.rglob("*")):
            if path.is_symlink() or not path.is_file():
                continue
            rel = path.relative_to(output)
            info = archive.gettarinfo(str(path), arcname=rel.as_posix())
            with path.open("rb") as handle:
                archive.addfile(info, handle)
    return 0


def rsync_boundary(command: str) -> int:
    """Allow rsync only when its single absolute path is one job input/output dir."""
    parts = shlex.split(command)
    if len(parts) < 3 or parts[0] != "rsync" or parts[1] != "--server":
        raise ValueError("unsupported rsync command")
    absolute = [part for part in parts[2:] if part.startswith("/")]
    if len(absolute) != 1:
        raise ValueError("rsync path is not singular")
    path = Path(absolute[0]).resolve(strict=False)
    jobs = (ROOT / "jobs").resolve()
    try:
        rel = path.relative_to(jobs)
    except ValueError as exc:
        raise ValueError("rsync path outside jobs") from exc
    if len(rel.parts) != 2 or rel.parts[0] == "" or rel.parts[1] not in {"input", "output"} or not JOB_RE.fullmatch(rel.parts[0]):
        raise ValueError("rsync path is not an input/output directory")
    os.execv("/usr/bin/rsync", parts)
    return 0


def main() -> int:
    command = os.environ.get("SSH_ORIGINAL_COMMAND", "").strip()
    try:
        if command == "probe":
            return reply(call({"op": "probe"}))
        parts = shlex.split(command)
        if len(parts) == 2 and parts[0] == "upload":
            return upload(parts[1])
        if len(parts) == 2 and parts[0] == "download":
            return download(parts[1])
        if len(parts) in {2, 3} and parts[0] in {"prepare", "status", "cancel", "cleanup", "logs"}:
            if parts[0] != "logs" and len(parts) != 2:
                raise ValueError("invalid command")
            offset = 0
            if len(parts) == 3:
                if parts[0] != "logs" or not parts[2].isdigit():
                    raise ValueError("invalid log offset")
                offset = int(parts[2])
            payload = {"op": parts[0], "job_id": ident(parts[1])}
            if parts[0] == "logs":
                payload["offset"] = offset
            return reply(call(payload))
        if len(parts) == 3 and parts[0] == "submit":
            return reply(call({"op": "submit", "job_id": ident(parts[1]), "runtime_id": parts[2], "jobs_file": "jobs.json"}))
        if command.startswith("rsync --server "):
            return rsync_boundary(command)
        raise ValueError("unsupported command")
    except Exception as exc:
        return reply({"ok": False, "error": str(exc)[:300]})


if __name__ == "__main__":
    raise SystemExit(main())
