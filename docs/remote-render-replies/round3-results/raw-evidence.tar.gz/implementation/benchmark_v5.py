#!/usr/bin/env python3
"""Long CPU curve and resource profiler for remote-render-agent v5.

This intentionally uses only the local Unix protocol and the supplied v4 kit.
It keeps raw samples under /srv/openmontage-render/bench-v5/evidence and never
touches the OpenMontage project tree.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import math
import os
import pwd
import re
import shutil
import socket
import statistics
import subprocess
import threading
import time
import urllib.request
from pathlib import Path
from profile_cpu import Counters, service_processes

ROOT = Path("/srv/openmontage-render")
KIT = ROOT / "bench-v4"
EVIDENCE = ROOT / "bench-v5" / "evidence"
SOCKET = "/run/openmontage-render/agent.sock"
RUNTIME = "om-20261007-remotion-v2"
PORTS = (7865, 7866, 7867, 7878)
CGROUP = "/system.slice/openmontage-render-agent.service"


def call(op: str, **kwargs):
    with socket.socket(socket.AF_UNIX) as sock:
        sock.settimeout(20)
        sock.connect(SOCKET)
        sock.sendall((json.dumps({"op": op, **kwargs}) + "\n").encode())
        response = json.loads(sock.makefile("rb").readline())
    if not response.get("ok"):
        raise RuntimeError(response)
    return response


def sh(*args: str) -> str:
    return subprocess.check_output(args, text=True).strip()


def cg_file(name: str) -> Path | None:
    for mount in (Path("/sys/fs/cgroup/cpu"), Path("/sys/fs/cgroup/cpuacct"), Path("/sys/fs/cgroup/pids")):
        path = mount / CGROUP.lstrip("/") / name
        if path.exists():
            return path
    return None


def read_kv(path: Path | None) -> dict[str, int]:
    if not path:
        return {}
    result = {}
    for line in path.read_text().splitlines():
        parts = line.split()
        if len(parts) == 2:
            try:
                result[parts[0]] = int(parts[1])
            except ValueError:
                pass
    return result


def read_cpu_lines() -> dict[str, list[int]]:
    result = {}
    for line in Path("/proc/stat").read_text().splitlines():
        parts = line.split()
        if parts and re.fullmatch(r"cpu\d+", parts[0]):
            result[parts[0]] = [int(x) for x in parts[1:]]
    return result


def cpu_delta(before, after):
    values = {}
    for name, prev in before.items():
        cur = after.get(name)
        if not cur:
            continue
        # guest/guest_nice are already included in user/nice.
        delta = [max(0, b - a) for a, b in zip(prev[:8], cur[:8])]
        total = sum(delta)
        idle = delta[3] + (delta[4] if len(delta) > 4 else 0)
        values[name] = round(100 * (total - idle) / total, 2) if total else 0.0
    return values


def meminfo():
    result = {}
    for line in Path("/proc/meminfo").read_text().splitlines():
        parts = line.split()
        if len(parts) >= 2:
            try:
                result[parts[0].rstrip(":")] = int(parts[1]) * (1024 if len(parts) > 2 and parts[2] == "kB" else 1)
            except ValueError:
                pass
    return {k: result.get(k, 0) for k in ("MemAvailable", "MemFree", "Cached", "SwapFree")}


def psi(name: str):
    result = {}
    try:
        for line in Path(f"/proc/pressure/{name}").read_text().splitlines():
            key, rest = line.split(" ", 1)
            result[key] = {k: float(v) for k, v in (p.split("=") for p in rest.split())}
    except (OSError, ValueError):
        pass
    return result


def diskstats():
    read_sectors = write_sectors = read_ios = write_ios = 0
    for line in Path("/proc/diskstats").read_text().splitlines():
        p = line.split()
        if len(p) >= 14 and p[2] in {"sda", "sdb", "sdc", "nvme0n1"}:
            read_ios += int(p[3]); read_sectors += int(p[5])
            write_ios += int(p[7]); write_sectors += int(p[9])
    return dict(read_ios=read_ios, read_sectors=read_sectors, write_ios=write_ios, write_sectors=write_sectors)


def process_sample():
    procs = []
    task_file = cg_file("cgroup.procs") or cg_file("tasks")
    pids = []
    if task_file:
        pids = sorted({int(x) for x in task_file.read_text().split() if x.isdigit()})
    groups = {}
    for pid in pids:
        try:
            comm = Path(f"/proc/{pid}/comm").read_text().strip()
            cmdline = Path(f"/proc/{pid}/cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace")
            stat = Path(f"/proc/{pid}/stat").read_text().split()
            status = Path(f"/proc/{pid}/status").read_text().splitlines()
            threads = next((int(x.split()[1]) for x in status if x.startswith("Threads:")), 1)
            rss = next((int(x.split()[1]) * 1024 for x in status if x.startswith("VmRSS:")), 0)
            ticks = int(stat[13]) + int(stat[14])
            lower = (comm + " " + cmdline).lower()
            kind = "chrome" if "chrome-headless" in lower else "ffmpeg" if "ffmpeg" in lower else "node" if "node" in lower else "other"
            if "ltx25-comfyui" in lower or "qwen-comfyui" in lower or "voxcpm" in lower or "knowledge" in lower:
                kind = "image_service"
            item = groups.setdefault(kind, {"pids": 0, "threads": 0, "rss": 0, "ticks": 0})
            item["pids"] += 1; item["threads"] += threads; item["rss"] += rss; item["ticks"] += ticks
            subtype = re.search(r'--type=([^ ]+)',cmdline)
            procs.append({"pid": pid, "kind": kind, "subtype": subtype[1] if subtype else 'main',
                          "threads": threads, "rss": rss, "ticks": ticks,
                          "args": cmdline if kind=='ffmpeg' else None})
        except (FileNotFoundError, PermissionError, ValueError, IndexError):
            continue
    return {"groups": groups, "processes": procs}


def topology():
    data = {}
    try:
        data["lscpu"] = subprocess.check_output(["lscpu", "-J"], text=True)
    except (OSError, subprocess.SubprocessError):
        data["lscpu"] = ""
    data["nproc"] = os.cpu_count()
    data["numa"] = sorted(str(p) for p in Path("/sys/devices/system/node").glob("node[0-9]*"))
    data["pmu"] = sorted(str(p) for p in Path("/sys/devices").glob("uncore_imc_*/events/cas_count_*"))
    data["perf_binary"] = shutil.which("perf")
    return data


class Sampler:
    def __init__(self, path: Path, label: str):
        self.path = path
        self.label = label
        self.stop = threading.Event()
        self.thread = threading.Thread(target=self.run, daemon=True)
        self.rows = []

    def start(self):
        self.thread.start()

    def run(self):
        before = read_cpu_lines(); c0 = read_kv(cg_file("cpu.stat")); started = time.monotonic()
        counters = Counters()
        (self.path.parent/'perf-availability.json').write_text(json.dumps({'open_counters':len(counters.fds),'errors':counters.errors},indent=2))
        previous_usage = int(cg_file('cpuacct.usage').read_text())
        with self.path.open("w") as out:
            while not self.stop.is_set():
                tick = time.monotonic()
                after = read_cpu_lines(); c1 = read_kv(cg_file("cpu.stat"))
                usage = int(cg_file('cpuacct.usage').read_text())
                total_ticks=sum(sum(after[k][:8])-sum(before[k][:8]) for k in before if k in after)
                wait_ticks=sum(after[k][4]-before[k][4] for k in before if k in after)
                row = {
                    "elapsed": round(time.monotonic() - started, 3),
                    "cpu_percent": cpu_delta(before, after),
                    "cpu_max": max(cpu_delta(before, after).values(), default=0),
                    "iowait_percent":100*wait_ticks/max(total_ticks,1),
                    "cgroup_cpu_stat": {k: c1.get(k, 0) - c0.get(k, 0) for k in ("nr_periods", "nr_throttled", "throttled_time")},
                    "meminfo": meminfo(), "psi_cpu": psi("cpu"), "psi_io": psi("io"), "psi_memory": psi("memory"),
                    "diskstats": diskstats(), "processes": process_sample(),
                    "cgroup_usage_ns": usage-previous_usage, "perf_delta":counters.delta(),
                    "image_processes": service_processes(),
                    "cgroup_memory_bytes": int((Path('/sys/fs/cgroup/memory')/CGROUP.lstrip('/')/'memory.usage_in_bytes').read_text()),
                }
                previous_usage = usage
                self.rows.append(row); out.write(json.dumps(row) + "\n"); out.flush()
                before, c0 = after, c1
                self.stop.wait(max(0,1-(time.monotonic()-tick)))
        counters.close()

    def close(self):
        self.stop.set(); self.thread.join(timeout=5)


def prepare(ident: str, start: int, frames: int, workers: int, tabs: int, render: dict, stills: bool, ffmpeg_threads=None):
    info = call("prepare", job_id=ident); dest = Path(info["input"])
    for name in ("composer", "public"):
        shutil.copytree(KIT / "input" / name, dest / name)
    shutil.copy2(KIT / "input/props.json", dest / "props.json")
    script = dest/'composer/render-tools/render_chunks.mjs'
    source = script.read_text()
    if ffmpeg_threads is not None:
        source = f'process.env.OM_RENDER_FFMPEG_THREADS = "{int(ffmpeg_threads)}";\n' + source
    source = source.replace('let browser = await openBrowser(', 'const omBrowserStart = performance.now();\nlet browser = await openBrowser(',1)
    source = source.replace('const composition = await selectComposition(', 'log(`@@timing browser_ms ${performance.now()-omBrowserStart}`);\nconst omCompositionStart = performance.now();\nconst composition = await selectComposition(',1)
    source = source.replace('if (jobs.infoOut)', 'log(`@@timing composition_ms ${performance.now()-omCompositionStart}`);\nif (jobs.infoOut)',1)
    script.write_text(source)
    account = pwd.getpwnam("openmontage-render")
    count = min(workers, frames); chunks = []
    for i in range(count):
        a = start + frames * i // count; b = start + frames * (i + 1) // count - 1
        chunks.append({"out": f"p{i:03}.mp4", "from": a, "to": b})
    spec = {"propsPath": "props.json", "publicDir": "public", "composition": "Explainer", "workers": workers,
            "concurrency": tabs, "timeoutMs": 1800000, "chunks": chunks, "stills": []}
    if render: spec["render"] = render
    if stills:
        spec["stills"] = [dict(out=f"{name}.png", frame=round(sec * 30)) for name, sec in
                          {"t00060": 6, "t01200": 120, "t01533": 153.3, "t01580": 158, "t02908": 290.8, "t03360": 336}.items()]
    (dest / "jobs.json").write_text(json.dumps(spec))
    for item in dest.rglob("*"):
        os.chown(item, account.pw_uid, account.pw_gid)
    return info["output"], spec


def ffprobe(path: Path):
    return json.loads(subprocess.check_output(["ffprobe", "-v", "error", "-select_streams", "v:0",
                                               "-show_entries", "stream=nb_frames,width,height,r_frame_rate,duration",
                                               "-of", "json", str(path)], text=True))


def quality(video: Path, evidence: Path):
    ref = KIT / "refs/ref_K4_3173-3472.mp4"
    stats = evidence / "video.psnr"
    graph = f"[0:v][1:v]psnr=stats_file={stats};[0:v][1:v]ssim"
    proc = subprocess.run(["ffmpeg", "-v", "info", "-threads", "2", "-i", str(video), "-threads", "2", "-i", str(ref),
                           "-filter_complex_threads", "2", "-lavfi", graph, "-f", "null", "-"], capture_output=True, text=True, check=True)
    (evidence / 'video.metrics.log').write_text(proc.stderr)
    values = [float(x) for x in re.findall(r"psnr_avg:(\S+)", stats.read_text())]
    ssim = float(re.search(r"SSIM.*All:([0-9.]+)", proc.stderr)[1])
    return {"min": min(values), "avg": sum(values) / len(values), "ssim": ssim, "frames": len(values)}


def parse_timing(log: Path, timeline: Path, started: float, finished: float):
    lines = log.read_text(errors="replace").splitlines()
    bundle = [float(m.group(1)) for line in lines if (m := re.search(r"bundle ok ([0-9.]+)s", line))]
    done = [float(m.group(1)) for line in lines if line.startswith('chunk ') and (m := re.search(r" done ([0-9.]+)s$", line))]
    events = [json.loads(line) for line in timeline.read_text().splitlines() if line.strip()]
    progress_time = next((float(item["at"]) for item in events if item["line"].startswith("@@progress")), None)
    first_chunk = next((float(item["at"]) for item in events if item["line"].startswith("chunk ")), None)
    render_start = progress_time or first_chunk or finished
    return {"bundle_seconds": bundle[0] if bundle else None, "chunk_done_seconds": done,
            "startup_seconds": round(render_start - started, 3), "render_seconds": round(finished - render_start, 3),
            "browser_ms": [float(x) for x in re.findall(r'@@timing browser_ms ([0-9.]+)',log.read_text())],
            "composition_ms": [float(x) for x in re.findall(r'@@timing composition_ms ([0-9.]+)',log.read_text())],
            "startup_note": 'submit-to-first-progress includes bundle, browser, composition and first frames; polling resolution 1s',
            "log_lines": len(lines)}


def run_one(name: str, workers: int, tabs: int, frames: int, start: int, quota: int, render: dict, stills: bool, ffmpeg_threads=None):
    waiting=time.monotonic()
    while True:
        probe=call('probe')
        if not probe['running'] and not probe['queued']:break
        if time.monotonic()-waiting>1800:raise RuntimeError('production queue remains busy')
        time.sleep(3)
    evidence = EVIDENCE / name; evidence.mkdir(parents=True, exist_ok=False)
    (evidence/'topology.json').write_text(json.dumps(topology(),indent=2))
    subprocess.run(["systemctl", "set-property", "openmontage-render-agent.service", f"CPUQuota={quota * 100}%"], check=True)
    ident = f"v5-{name}-0"
    output, spec = prepare(ident, start, frames, workers, tabs, render, stills, ffmpeg_threads)
    (evidence/'spec.json').write_text(json.dumps(spec,indent=2))
    sampler = Sampler(evidence / "telemetry.jsonl", name); sampler.start()
    submitted = time.monotonic(); call("submit", job_id=ident, runtime_id=RUNTIME, jobs_file="jobs.json")
    offset = 0; log_path = evidence / "render.log"; log_path.write_text("")
    timeline_path = evidence / "timeline.jsonl"; timeline_path.write_text("")
    started_at = None; finished_at = None; status = None
    health_path = evidence/'health.jsonl'
    foreign=set()
    with log_path.open("a") as log, timeline_path.open("a") as timeline, health_path.open('w') as health_out, (evidence/'status-poll.jsonl').open('w') as status_out:
        while True:
            status = call("status", job_id=ident)
            status_out.write(json.dumps({'at':time.time(),'status':status})+'\n');status_out.flush()
            foreign.update(j for j in status.get('active_jobs',[]) if j!=ident)
            if status.get("started_at") and started_at is None: started_at = time.monotonic()
            part = call("logs", job_id=ident, offset=offset); offset = part["next"]
            for line in part["log"].splitlines():
                log.write(line + "\n")
                timeline.write(json.dumps({"at": time.monotonic(), "line": line}) + "\n")
            log.flush(); timeline.flush()
            if int(time.monotonic()-submitted)%3==0:
                readings=[]
                for port in PORTS:
                    tick=time.monotonic()
                    try:
                        with urllib.request.urlopen(f'http://127.0.0.1:{port}/queue',timeout=2) as response:
                            q=json.load(response)
                        readings.append({'port':port,'ms':(time.monotonic()-tick)*1000,'running':len(q['queue_running']),'pending':len(q['queue_pending'])})
                    except Exception as exc:
                        readings.append({'port':port,'error':str(exc)})
                health_out.write(json.dumps({'at':time.time(),'services':readings})+'\n');health_out.flush()
            if status["state"] in {"completed", "failed", "canceled"}:
                finished_at = time.monotonic(); break
            time.sleep(1)
    sampler.close()
    (evidence/'status.json').write_text(json.dumps(status,indent=2))
    if status["state"] != "completed":
        # Keep failed job/output for diagnosis; never discard failed evidence.
        raise RuntimeError(status)
    out = Path(output); manifest = json.loads((out / "manifest.json").read_text())
    for entry in manifest["files"]:
        path = out / entry["path"]
        assert path.stat().st_size == entry["bytes"] and hashlib.sha256(path.read_bytes()).hexdigest() == entry["sha256"]
    shutil.copy2(out / "manifest.json", evidence / "manifest.json"); shutil.copytree(out, evidence / "output")
    chunks = [out / item["out"] for item in spec["chunks"]]
    list_file = evidence / "concat.txt"; list_file.write_text("".join(f"file '{p}'\n" for p in chunks))
    joined = evidence / "joined.mp4"
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", str(list_file), "-c", "copy", str(joined)], check=True)
    timing = parse_timing(log_path, timeline_path, started_at or submitted, finished_at or time.monotonic())
    report = {"name": name, "workers": workers, "tabs": tabs, "frames": frames, "start": start, "quota_cores": quota,
              "seconds": round(status["finished_at"] - status["started_at"], 3), "wall_seconds": round((finished_at or time.monotonic()) - submitted, 3),
              "fps": round(frames / (status["finished_at"] - status["started_at"]), 3), "render": render,
              "ffmpeg_threads": ffmpeg_threads,
              "timing": timing, "peak_tasks": max((sum(g['threads'] for g in r['processes']['groups'].values()) for r in sampler.rows), default=0),
              "telemetry_samples": len(sampler.rows), "stream": ffprobe(joined)}
    assert int(report['stream']['streams'][0]['nb_frames'])==frames
    report['errors'] = re.findall(r'EAGAIN|EPIPE|Target closed|EACCES|worker \d+ failed',log_path.read_text())
    report['foreign_jobs']=sorted(foreign)
    report['valid_performance_sample']=not foreign and not report['errors']
    if ffmpeg_threads is not None:
        ffargs=[p.get('args','') for r in sampler.rows for p in r['processes']['processes'] if p['kind']=='ffmpeg']
        report['thread_hook_observed']=any(f'-threads {ffmpeg_threads} ' in cmd for cmd in ffargs)
        assert report['thread_hook_observed'], 'requested ffmpeg threads not observed in actual child argv'
    if frames == 300 and start == 3173:
        report["video"] = quality(joined, evidence)
    if stills:
        stills_result = {}
        for path in sorted((KIT / "refs/stills").glob("*.png")):
            rendered = evidence / "output" / path.name
            # Compare decoded pixels, not PNG metadata/compression bytes.
            pixel_hashes=[]
            for image in (rendered,path):
                pixel_hashes.append(subprocess.check_output(['ffmpeg','-v','error','-threads','1','-i',str(image),'-f','hash','-hash','sha256','-']))
            stills_result[path.stem] = {"pixel_identical": pixel_hashes[0]==pixel_hashes[1]}
        report["stills"] = stills_result
    if report.get('video') or stills:
        report['quality_pass']=(report.get('video',{}).get('min',100)>=45 and
                                all(v['pixel_identical'] for v in report.get('stills',{}).values()))
    (evidence / "result.json").write_text(json.dumps(report, indent=2))
    call("cleanup", job_id=ident)
    return report


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True); ap.add_argument("--workers", type=int, required=True)
    ap.add_argument("--tabs", type=int, default=2); ap.add_argument("--frames", type=int, default=2236)
    ap.add_argument("--start", type=int, default=0); ap.add_argument("--quota", type=int, default=48)
    ap.add_argument("--render", default="{}"); ap.add_argument("--stills", action="store_true")
    ap.add_argument('--ffmpeg-threads',type=int,choices=[1,2,4,8])
    args = ap.parse_args(); EVIDENCE.mkdir(parents=True, exist_ok=True)
    render = json.loads(args.render)
    print(json.dumps(run_one(args.name, args.workers, args.tabs, args.frames, args.start, args.quota, render, args.stills, args.ffmpeg_threads)), flush=True)


if __name__ == "__main__":
    main()
