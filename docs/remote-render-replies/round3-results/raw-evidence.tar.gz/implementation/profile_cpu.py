"""Read-only Linux CPU/perf observations; counters only, no global tuning."""
import ctypes
import os
import re
import struct
from pathlib import Path


class Counters:
    def __init__(self):
        self.lib = ctypes.CDLL(None, use_errno=True)
        self.fds = []
        self.errors = []
        for cpu in range(os.cpu_count() or 1):
            for name, event in [('cycles', 0), ('instructions', 1), ('cache_references', 2), ('cache_misses', 3)]:
                self.open(0, event, cpu, name, 1.0, (1 << 5) | (1 << 6))
        for pmu in sorted(Path('/sys/devices').glob('uncore_imc_*')):
            if not (pmu/'events/cas_count_read').exists():
                continue
            try:
                cpus = []
                for part in (pmu/'cpumask').read_text().strip().split(','):
                    bounds = [int(n) for n in part.split('-')]
                    cpus.extend(range(bounds[0], bounds[-1]+1))
                typ = int((pmu/'type').read_text())
                for direction in ['read', 'write']:
                    path = pmu/f'events/cas_count_{direction}'
                    terms = dict(s.split('=') for s in path.read_text().strip().split(','))
                    config = int(terms['event'], 0) | (int(terms['umask'], 0) << 8)
                    scale = float(Path(str(path)+'.scale').read_text())
                    for cpu in cpus:
                        self.open(typ, config, cpu, 'memory_'+direction+'_mib', scale, 0)
            except (ValueError, OSError) as exc:
                self.errors.append(str(exc))
        self.previous = self.read()

    def open(self, typ, config, cpu, name, scale, flags):
        attr = bytearray(128)
        struct.pack_into('IIQ', attr, 0, typ, 128, config)
        struct.pack_into('Q', attr, 32, 3)  # total time enabled/running
        struct.pack_into('Q', attr, 40, flags)
        buf = (ctypes.c_char*128).from_buffer(attr)
        fd = self.lib.syscall(298, ctypes.byref(buf), -1, cpu, -1, 0)
        if fd < 0:
            message = f'{name}: {os.strerror(ctypes.get_errno())}'
            if message not in self.errors:
                self.errors.append(message)
        else:
            self.fds.append((fd, name, scale))

    def read(self):
        result = {}
        for fd, name, scale in self.fds:
            try:
                value, enabled, running = struct.unpack('QQQ', os.read(fd, 24))
                result[fd] = (value, enabled, running)
            except OSError:
                continue
        return result

    def delta(self):
        current = self.read()
        sums = {}
        for fd, name, scale in self.fds:
            if fd not in current or fd not in self.previous:
                continue
            dv, de, dr = [b-a for a,b in zip(self.previous[fd], current[fd])]
            if dr:
                sums[name] = sums.get(name, 0) + dv*de/dr*scale
        self.previous = current
        return sums

    def close(self):
        for fd, _, _ in self.fds:
            os.close(fd)


def service_processes():
    # Read known image-service processes by executable path, never their env.
    result = []
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():
            continue
        try:
            raw = (p/'cmdline').read_bytes().split(b'\0')
            executable = raw[0].decode(errors='replace')
            if not any(x in executable for x in ['ltx25-comfyui/', 'qwen-comfyui/', 'VoxCPM/', 'Open-LLM-VTuber/']):
                continue
            stat = (p/'stat').read_text().split(') ', 1)[1].split()
            result.append({'pid':int(p.name),'cpu_ticks':int(stat[11])+int(stat[12]),'nice':int(stat[16]),'threads':int(stat[17]),'executable':executable})
        except (OSError, ValueError, IndexError):
            continue
    return result
