import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import agent
from benchmark_v5 import cpu_delta


class V5Checks(unittest.TestCase):
    def test_probe_reports_cpu_time_not_load_average(self):
        with patch.object(agent,'_cpu_sample',(1,100,60,0)), patch.object(agent,'_cpu_times',return_value=(200,110)), patch('agent.time.monotonic',return_value=2):
            busy, available=agent.proc_load()
            self.assertEqual(busy,50)
            self.assertGreater(available,0)

    def test_cpu_delta_separates_idle_and_wait(self):
        result=cpu_delta({'cpu0':[10,0,5,100,0]}, {'cpu0':[30,0,15,150,20]})
        self.assertEqual(result, {'cpu0':30.0})

    def test_probe_after_long_idle_takes_fresh_sample(self):
        with patch.object(agent,'_cpu_sample',(1,100,90,0)), patch.object(agent,'_cpu_times',side_effect=[(200,190),(300,240)]), patch('agent.time.monotonic',return_value=100), patch('agent.time.sleep') as wait:
            self.assertEqual(agent.proc_load()[0],50)
            wait.assert_called_once_with(0.1)

    def test_tmp_cleanup_cannot_escape_private_root(self):
        with patch('agent.remove_tree') as remove:
            for value in ['/tmp/user','/dev/shm/openmontage-render/../user','/dev/shm/openmontage-render','/dev/shm/openmontage-render/x/y']:
                agent.Agent._cleanup_tmp({'tmp_dir':value})
            remove.assert_not_called()
            agent.Agent._cleanup_tmp({'tmp_dir':'/dev/shm/openmontage-render/v5-test'})
            remove.assert_called_once_with(Path('/dev/shm/openmontage-render/v5-test'))

    def test_runtime_installer_cjs_esm_idempotence_and_reject_unknown(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);base=root/'node_modules/@remotion/renderer/dist'
            (base/'esm').mkdir(parents=True)
            cjs=base/'ffmpeg-args.js';esm=base/'esm/index.mjs'
            cjs.write_text("        ['-pix_fmt', pixelFormat],\n")
            esm.write_text('    ["-pix_fmt", pixelFormat],\n')
            cmd=[sys.executable,str(Path(__file__).with_name('install_ffmpeg_threads.py')),str(root)]
            subprocess.run(cmd,check=True,capture_output=True)
            after=[p.read_bytes() for p in (cjs,esm)]
            subprocess.run(cmd,check=True,capture_output=True)
            self.assertEqual(after,[p.read_bytes() for p in (cjs,esm)])
            for p in (cjs,esm):self.assertIn('OM_RENDER_FFMPEG_THREADS',p.read_text())
            cjs.write_text("        ['-pix_fmt', pixelFormat],\n")
            esm.write_text('unknown')
            self.assertNotEqual(subprocess.run(cmd,capture_output=True).returncode,0)
            self.assertNotIn('OM_RENDER_FFMPEG_THREADS',cjs.read_text())

if __name__=='__main__':unittest.main()
